# -*- coding: utf-8 -*-

from odoo import fields, models, api

class vehiculo(models.Model):
    _name = "vehiculo"
    name = fields.Char(string='vehiculo')
    color = fields.Selection(selection=[
        ('Rojo','Rojo'),
        ('verde','Verde'),
        ('azul','Azul'),
        ('negro','Negro'),
        ('amarillo','Amarillo'),
    ], string='Color')
    puertas = fields.Integer(string='PUERTAS')
    matricula = fields.Char(string='MATRICULA')
    kms = fields.Float(string='KMS', defautl=1, digits=(8,3))
    num_bastidor = fields.Char(string='NUM_BASTIDOR')
    cilindrada = fields.Integer(string='CC')
    combustible = fields.Selection(selection=[
        ('gasolino','gasolina'),
        ('diesel','diesel'),
        ('electrico','electrico'),
    ], string='Combustible')
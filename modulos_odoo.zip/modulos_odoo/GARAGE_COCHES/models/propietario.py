# -*- coding: utf-8 -*-

from odoo import fields, models, api

class Propietario(models.Model):
    _name = "propietario"
    name = fields.Char(string='NAME')
    telefono = fields.Char(string='TELEFONO')
    direccion = fields.Char(string='DIRECCION')
    ingresos_anuales = fields.Integer(string='INGRESOS ANO')
    ingresos_mensuales = fields.Integer(string='INGRESOS MES')
    coches = fields.Many2one(
         comodel_name='vehiculo',
         string='colores'
     )
    # categoria_coches = fields.Many2one(
    #      comodel_name='color',
    #      string='Categoria coches',
    #      default=lambda self: self.env.ref('propietario.color')
    #  )

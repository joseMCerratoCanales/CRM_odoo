# -*- coding: utf-8 -*-

from . import propietario
from . import vehiculo
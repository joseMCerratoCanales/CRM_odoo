# -*- coding: utf-8 -*-
{
    'name': 'Modulo de vehiculos',
    'version': '1.0',
    'depends': ['base',],
    'author': 'Jose Manuel Cerrato',
    'category': 'vehiculos',
    'website': 'http://www.elcorteingles.com',
    'description': '''
    Modulo para hacer garage_coches
    ''',
    'data': [
        'views\propietario_views.xml',
        'views\menu.xml',

    ],
}